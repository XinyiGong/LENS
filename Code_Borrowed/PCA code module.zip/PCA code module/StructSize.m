function S=StructSize(A)
Astr=size(A);
S=Astr(1,1);
end